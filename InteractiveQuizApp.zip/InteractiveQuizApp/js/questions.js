/**
 * questions.js
 * All quiz questions organised by topic → difficulty.
 * Each question: { q, opts[], ans (index), exp }
 */

const QUESTIONS = {

  javascript: {
    easy: [
      {
        q: "What keyword declares a variable that cannot be reassigned?",
        opts: ["let", "var", "const", "static"],
        ans: 2,
        exp: "const declares a block-scoped variable that cannot be reassigned after initialisation."
      },
      {
        q: "Which method adds an element to the end of an array?",
        opts: ["push()", "pop()", "shift()", "splice()"],
        ans: 0,
        exp: "push() appends one or more elements to the end of an array and returns the new length."
      },
      {
        q: "What does typeof null return in JavaScript?",
        opts: ["null", "undefined", "object", "boolean"],
        ans: 2,
        exp: "This is a long-standing bug — typeof null returns 'object', not 'null'."
      },
      {
        q: "Which symbol starts a single-line comment in JavaScript?",
        opts: ["/* */", "//", "#", "--"],
        ans: 1,
        exp: "Double forward slashes // start a single-line comment in JavaScript."
      },
      {
        q: "What is the correct way to write a JavaScript array?",
        opts: ["var x = (1,2,3)", "var x = [1,2,3]", "var x = {1,2,3}", "var x = '1,2,3'"],
        ans: 1,
        exp: "Arrays in JavaScript are written with square brackets []."
      },
      {
        q: "Which operator checks both value AND type equality?",
        opts: ["==", "=", "===", "!="],
        ans: 2,
        exp: "=== is the strict equality operator — it checks both value and data type without coercion."
      },
      {
        q: "What does NaN stand for?",
        opts: ["Not a Node", "Not a Number", "Null and None", "New and Nested"],
        ans: 1,
        exp: "NaN stands for 'Not a Number' — it represents an invalid or unrepresentable numeric value."
      }
    ],
    medium: [
      {
        q: "What does the spread operator (...) do when used with an array?",
        opts: ["Creates a new array reference", "Expands elements into individual values", "Removes duplicates", "Sorts the array"],
        ans: 1,
        exp: "The spread operator expands an iterable into individual elements, e.g. [...arr1, ...arr2] merges arrays."
      },
      {
        q: "Which array method creates a new array from elements that pass a test?",
        opts: ["find()", "map()", "filter()", "reduce()"],
        ans: 2,
        exp: "filter() returns a new array containing only elements for which the callback returns true."
      },
      {
        q: "What is a closure in JavaScript?",
        opts: ["A way to close the browser", "A function with access to its outer scope variables", "A method to close network connections", "An error handling mechanism"],
        ans: 1,
        exp: "A closure is a function that retains access to variables from its lexical scope even after the outer function has returned."
      },
      {
        q: "What does Promise.all() do?",
        opts: ["Runs promises sequentially", "Runs all promises in parallel and waits for all", "Returns the first resolved promise", "Cancels all promises"],
        ans: 1,
        exp: "Promise.all() takes an array of promises and resolves when all resolve, or rejects if any one rejects."
      },
      {
        q: "What is event delegation?",
        opts: ["Passing events between windows", "Attaching one listener to a parent to handle child events", "Delaying event execution", "Blocking default browser behaviour"],
        ans: 1,
        exp: "Event delegation uses event bubbling — you attach a single listener on a parent element to handle events fired by its children."
      },
      {
        q: "Which method removes whitespace from both ends of a string?",
        opts: ["strip()", "clean()", "trim()", "remove()"],
        ans: 2,
        exp: "trim() removes leading and trailing whitespace characters from a string without modifying the original."
      },
      {
        q: "What is the output of: console.log(0.1 + 0.2 === 0.3)?",
        opts: ["true", "false", "NaN", "undefined"],
        ans: 1,
        exp: "Due to IEEE 754 floating-point precision, 0.1 + 0.2 equals 0.30000000000000004, not exactly 0.3."
      }
    ],
    hard: [
      {
        q: "What is the output of: [1,2,3].reduce((a,b) => a + b, 10)?",
        opts: ["6", "16", "10", "NaN"],
        ans: 1,
        exp: "reduce starts with accumulator 10, then adds 1 (=11), 2 (=13), 3 (=16). The second argument is the initial value."
      },
      {
        q: "What does Object.freeze() do?",
        opts: ["Deep-freezes all nested objects", "Makes an object's properties non-writable and non-configurable", "Prevents the variable from being reassigned", "Converts the object to a string"],
        ans: 1,
        exp: "Object.freeze() makes properties non-writable and non-configurable and prevents adding new ones. It's shallow — nested objects are not frozen."
      },
      {
        q: "What is the Temporal Dead Zone (TDZ)?",
        opts: ["Time before a page loads", "Period where let/const exist but cannot be accessed", "A deprecated JavaScript API", "Scope outside any function"],
        ans: 1,
        exp: "TDZ is the time between entering a scope and the let/const declaration being evaluated. Accessing the variable in this zone throws a ReferenceError."
      },
      {
        q: "What does Symbol.iterator define on an object?",
        opts: ["The object's string representation", "How the object behaves in for...of loops", "The object's constructor", "A unique ID for the object"],
        ans: 1,
        exp: "Symbol.iterator is a well-known symbol that defines an object's default iteration behaviour, used by for...of, spread, and destructuring."
      },
      {
        q: "What is a WeakMap best suited for?",
        opts: ["Storing primitive values", "Storing key-value pairs where keys are objects and can be garbage-collected", "Caching large datasets permanently", "Replacing regular objects entirely"],
        ans: 1,
        exp: "WeakMap holds key-value pairs where keys must be objects and are held weakly — they won't prevent garbage collection when there are no other references."
      },
      {
        q: "What is the output of: typeof class {}?",
        opts: ["class", "object", "undefined", "function"],
        ans: 3,
        exp: "Classes in JavaScript are syntactic sugar over functions. typeof class {} returns 'function'."
      },
      {
        q: "Which best describes tail call optimisation?",
        opts: ["Removing the last element of an array efficiently", "Reusing the current stack frame when the last action is a function call", "Caching the result of recursive calls", "Automatically parallelising function calls"],
        ans: 1,
        exp: "TCO reuses the current stack frame for a tail call (a function call as the very last action), preventing stack overflow in deep recursion."
      }
    ]
  },

  webdev: {
    easy: [
      {
        q: "What does HTML stand for?",
        opts: ["HyperText Markup Language", "High Transfer Machine Language", "HyperText Modern Language", "Home Tool Markup Language"],
        ans: 0,
        exp: "HTML stands for HyperText Markup Language — the standard language for creating web pages."
      },
      {
        q: "Which HTML tag creates the largest heading?",
        opts: ["<h6>", "<heading>", "<h1>", "<head>"],
        ans: 2,
        exp: "<h1> is the highest-level heading tag. Headings go from h1 (largest) to h6 (smallest)."
      },
      {
        q: "What does CSS stand for?",
        opts: ["Creative Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Custom Styling Service"],
        ans: 1,
        exp: "CSS stands for Cascading Style Sheets — it describes how HTML elements should be displayed."
      },
      {
        q: "Which CSS property changes the text colour?",
        opts: ["font-color", "text-color", "color", "foreground"],
        ans: 2,
        exp: "The color property in CSS sets the foreground colour of text content."
      },
      {
        q: "What is the purpose of the alt attribute on images?",
        opts: ["Sets image dimensions", "Provides alternative text for accessibility", "Links to another image", "Adds a caption"],
        ans: 1,
        exp: "The alt attribute provides alternative text for screen readers and displays if the image fails to load — crucial for accessibility."
      },
      {
        q: "Which HTTP method is typically used to send form data?",
        opts: ["GET", "PUT", "POST", "DELETE"],
        ans: 2,
        exp: "POST sends data to a server to create or update a resource — commonly used for form submissions."
      },
      {
        q: "What does 'responsive design' mean?",
        opts: ["Pages load very fast", "Pages adapt their layout to different screen sizes", "Pages respond to voice commands", "Pages have animations"],
        ans: 1,
        exp: "Responsive web design uses flexible layouts, images, and CSS media queries so pages look good on all device sizes."
      }
    ],
    medium: [
      {
        q: "What is the CSS Box Model?",
        opts: ["A tool for drawing shapes", "Content, padding, border, and margin layers around an element", "A grid system for layouts", "A JavaScript animation model"],
        ans: 1,
        exp: "The CSS box model describes how every HTML element is surrounded by content, padding, border, and margin — affecting total size and spacing."
      },
      {
        q: "What does 'semantic HTML' mean?",
        opts: ["HTML with inline styles", "Using tags that convey meaning about the content", "HTML validated by W3C", "HTML with no class names"],
        ans: 1,
        exp: "Semantic HTML uses meaningful tags like <article>, <nav>, <header> that describe content roles, improving accessibility and SEO."
      },
      {
        q: "What is Flexbox used for in CSS?",
        opts: ["Drawing SVG shapes", "3D transformations", "One-dimensional layout of items in a row or column", "Animating page transitions"],
        ans: 2,
        exp: "Flexbox is a CSS layout model for distributing space among items in a container along a single axis (row or column)."
      },
      {
        q: "What is a CSS media query?",
        opts: ["A JavaScript API to fetch media files", "CSS rules applied based on device characteristics", "A server-side image optimisation technique", "An HTML attribute for video"],
        ans: 1,
        exp: "Media queries apply CSS rules conditionally based on screen width, resolution, orientation, and other device characteristics."
      },
      {
        q: "What is the difference between id and class attributes?",
        opts: ["No difference", "id is unique per page; class can be reused on many elements", "class is unique per page; id can be reused", "id applies only to divs"],
        ans: 1,
        exp: "id must be unique on a page; class can be applied to multiple elements and many elements can share the same class name."
      },
      {
        q: "What is ARIA in web development?",
        opts: ["A JavaScript framework", "Accessible Rich Internet Applications — HTML attributes for accessibility", "A CSS animation library", "An API for audio/video"],
        ans: 1,
        exp: "ARIA (Accessible Rich Internet Applications) provides attributes like role, aria-label, and aria-hidden to improve accessibility for assistive technologies."
      },
      {
        q: "What does z-index control in CSS?",
        opts: ["Horizontal position", "Zoom level", "Stacking order of positioned elements", "Animation speed"],
        ans: 2,
        exp: "z-index controls the vertical stacking order of positioned elements. Higher values appear on top."
      }
    ],
    hard: [
      {
        q: "What is the Critical Rendering Path (CRP)?",
        opts: ["The fastest network route to a server", "Steps the browser takes to convert HTML/CSS/JS into pixels", "The order CSS rules are applied", "The minimum code needed to render a page"],
        ans: 1,
        exp: "CRP is the sequence browsers follow: parse HTML → build DOM, parse CSS → build CSSOM, combine into Render Tree, Layout, then Paint."
      },
      {
        q: "What is Content Security Policy (CSP)?",
        opts: ["A performance budget for web pages", "An HTTP header that controls which resources a page can load", "A JavaScript sandboxing technique", "A way to compress HTML"],
        ans: 1,
        exp: "CSP is an HTTP header that lets server admins whitelist sources of scripts, styles, and other resources to prevent XSS attacks."
      },
      {
        q: "What is the purpose of will-change in CSS?",
        opts: ["Declares CSS custom properties", "Hints the browser to prepare GPU layers for upcoming animations", "Sets which properties can be inherited", "Prefixes vendor-specific properties"],
        ans: 1,
        exp: "will-change hints to the browser that an element will undergo a transformation so it can optimise rendering in advance, typically creating a GPU compositing layer."
      },
      {
        q: "What is paint flashing in browser DevTools?",
        opts: ["A tool to test colour contrast", "Highlighting regions that are re-painted every frame", "A CSS debugging technique", "Animating screen transitions"],
        ans: 1,
        exp: "Paint flashing (green overlay in Chrome DevTools) highlights regions that trigger raster/paint operations each frame, useful for diagnosing rendering performance."
      },
      {
        q: "What is the difference between visibility:hidden and display:none?",
        opts: ["They are identical", "visibility:hidden keeps layout space; display:none removes from layout entirely", "display:none keeps space; visibility:hidden removes it", "Only display:none works in all browsers"],
        ans: 1,
        exp: "visibility:hidden makes an element invisible but it still occupies space. display:none removes the element from the document flow entirely."
      },
      {
        q: "What is tree shaking in JavaScript bundlers?",
        opts: ["Removing deeply nested components", "Eliminating unused code from the final bundle", "Sorting components alphabetically", "Optimising CSS selectors"],
        ans: 1,
        exp: "Tree shaking is a dead-code elimination technique used by bundlers (Webpack, Rollup) that removes exports never imported anywhere in the app."
      },
      {
        q: "What is 'layout thrashing' and how do you avoid it?",
        opts: ["Excessive use of flexbox; use grid instead", "Alternating DOM reads/writes causing forced synchronous layouts; batch reads then writes", "Too many CSS animations; use requestAnimationFrame", "Using too many fonts; self-host them"],
        ans: 1,
        exp: "Layout thrashing occurs when JS alternately reads and writes layout properties, forcing repeated recalculations. Batch all reads before writes to avoid it."
      }
    ]
  },

  general: {
    easy: [
      {
        q: "What is RAM an abbreviation for?",
        opts: ["Read Access Memory", "Random Access Memory", "Rapid Action Module", "Readable Application Memory"],
        ans: 1,
        exp: "RAM stands for Random Access Memory — temporary storage your computer uses for actively running programs."
      },
      {
        q: "Which search engine has the largest global market share?",
        opts: ["Bing", "Yahoo", "Google", "DuckDuckGo"],
        ans: 2,
        exp: "Google holds approximately 90%+ of the global search engine market share."
      },
      {
        q: "What does URL stand for?",
        opts: ["Universal Resource Locator", "Uniform Resource Locator", "Unified Reference Link", "Universal Reference Location"],
        ans: 1,
        exp: "URL stands for Uniform Resource Locator — the address used to access a resource on the internet."
      },
      {
        q: "Who is known as the father of the World Wide Web?",
        opts: ["Bill Gates", "Steve Jobs", "Linus Torvalds", "Tim Berners-Lee"],
        ans: 3,
        exp: "Tim Berners-Lee invented the World Wide Web in 1989 while working at CERN."
      },
      {
        q: "What does CPU stand for?",
        opts: ["Central Processing Unit", "Computer Personal Unit", "Control Program Utility", "Core Processing Unit"],
        ans: 0,
        exp: "CPU stands for Central Processing Unit — the primary component that executes instructions in a computer."
      },
      {
        q: "Which company created the Android operating system?",
        opts: ["Apple", "Microsoft", "Google", "Samsung"],
        ans: 2,
        exp: "Android was developed by Android Inc., acquired by Google in 2005. Google continues to develop it."
      },
      {
        q: "What does 'open source' mean?",
        opts: ["Free to download", "Source code is publicly available to view, modify, and distribute", "Software with no bugs", "Cloud-based software"],
        ans: 1,
        exp: "Open source software has its source code publicly available, allowing anyone to inspect, modify, and distribute it."
      }
    ],
    medium: [
      {
        q: "What is the primary purpose of a firewall?",
        opts: ["Speed up internet connection", "Monitor screen brightness", "Block unauthorized network access", "Manage file storage"],
        ans: 2,
        exp: "A firewall monitors network traffic based on security rules, acting as a barrier between trusted and untrusted networks."
      },
      {
        q: "What is machine learning?",
        opts: ["Programming robots to walk", "Training computers to learn from data without being explicitly programmed", "A type of computer hardware", "Programming using machine code"],
        ans: 1,
        exp: "Machine learning is a subset of AI where systems learn from data, identify patterns, and make decisions with minimal human intervention."
      },
      {
        q: "What does API stand for?",
        opts: ["Application Programming Interface", "Automated Protocol Integration", "Advanced Program Installer", "Application Process Index"],
        ans: 0,
        exp: "API stands for Application Programming Interface — it defines how software components should interact."
      },
      {
        q: "What is cloud computing?",
        opts: ["Computing using weather data", "Delivering computing services over the internet on-demand", "A type of encryption algorithm", "Storing files in a physical data centre you own"],
        ans: 1,
        exp: "Cloud computing delivers services (servers, storage, databases, networking, software) over the internet, enabling on-demand access without owning hardware."
      },
      {
        q: "What is two-factor authentication (2FA)?",
        opts: ["Using two different passwords", "Logging in from two devices", "Requiring a second verification step beyond a password", "Encrypting data twice"],
        ans: 2,
        exp: "2FA adds a second layer of security by requiring a second verification form (like an SMS code) in addition to your password."
      },
      {
        q: "What does encryption do to data?",
        opts: ["Compresses it to save space", "Converts it into an unreadable format without the decryption key", "Makes it load faster", "Backs it up automatically"],
        ans: 1,
        exp: "Encryption converts readable data (plaintext) into unreadable ciphertext using an algorithm and key, so only authorised parties can read it."
      },
      {
        q: "What is the difference between the internet and the World Wide Web?",
        opts: ["They are the same thing", "Internet is the global network infrastructure; the Web is a service running on it", "The Web is faster than the internet", "Internet is for data, the Web is for video only"],
        ans: 1,
        exp: "The internet is the global physical network. The World Wide Web is one service that runs on it — a system of interlinked web pages accessed via HTTP."
      }
    ],
    hard: [
      {
        q: "What is the CAP theorem in distributed systems?",
        opts: ["A rule about cache sizes", "A system can only guarantee two of: Consistency, Availability, Partition tolerance", "A networking protocol", "A cryptographic principle"],
        ans: 1,
        exp: "CAP theorem: a distributed system can only provide two of three guarantees simultaneously — Consistency, Availability, and Partition tolerance."
      },
      {
        q: "What is a race condition?",
        opts: ["A performance benchmark test", "A bug where outcome depends on unpredictable timing of concurrent operations", "A competition between two algorithms", "A memory allocation strategy"],
        ans: 1,
        exp: "A race condition occurs when the system's behaviour depends on the sequence or timing of uncontrollable events (like threads), leading to non-deterministic bugs."
      },
      {
        q: "What is eventual consistency in databases?",
        opts: ["Data is always immediately consistent", "Given no new updates, all replicas will converge to the same value over time", "Transactions are rolled back if inconsistent", "Data is sorted eventually"],
        ans: 1,
        exp: "Eventual consistency guarantees that, given enough time without new writes, all replicas in a distributed system will converge to the same value."
      },
      {
        q: "What does ACID stand for in database transactions?",
        opts: ["Automatic, Consistent, Isolated, Durable", "Atomicity, Consistency, Isolation, Durability", "Archived, Cached, Indexed, Distributed", "Access, Control, Integrity, Deletion"],
        ans: 1,
        exp: "ACID: Atomicity (all or nothing), Consistency (valid state transitions), Isolation (transactions don't interfere), Durability (committed data persists)."
      },
      {
        q: "What is a hash collision?",
        opts: ["When a server crashes due to high traffic", "When two different inputs produce the same hash output", "When encryption fails", "When a cache is cleared"],
        ans: 1,
        exp: "A hash collision occurs when two distinct inputs produce identical hash output. Good hash functions minimise collisions but can't eliminate them entirely."
      },
      {
        q: "What is the difference between symmetric and asymmetric encryption?",
        opts: ["Symmetric is stronger", "Symmetric uses one key for encrypt/decrypt; asymmetric uses a public/private key pair", "Asymmetric is faster", "Symmetric uses two different keys"],
        ans: 1,
        exp: "Symmetric encryption uses the same key for both operations (fast, e.g. AES). Asymmetric uses a public key to encrypt and private key to decrypt (e.g. RSA)."
      },
      {
        q: "What is a deadlock in computing?",
        opts: ["A crash caused by too many threads", "A state where two or more processes each hold a resource the other needs, blocking forever", "A network timeout", "Memory that can never be freed"],
        ans: 1,
        exp: "A deadlock occurs when two or more processes are waiting for each other to release resources, creating a circular dependency that blocks all of them indefinitely."
      }
    ]
  }
};
