/**
 * app.js
 * Main application controller.
 * Wires together Quiz engine and UI — handles all user interactions.
 */

document.addEventListener('DOMContentLoaded', () => {

  // ── Start Screen Setup ────────────────────────────────
  UI.buildTopicGrid(Quiz.TOPICS, Quiz.getTopic(), (topic) => {
    Quiz.setTopic(topic);
  });

  // Difficulty buttons
  document.querySelectorAll('.diff-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      Quiz.setDifficulty(btn.dataset.diff);
    });
  });

  // Start button
  const startBtn = document.getElementById('startBtn');
  if (startBtn) startBtn.addEventListener('click', startQuiz);

  // Next button
  const nextBtn = document.getElementById('nextBtn');
  if (nextBtn) nextBtn.addEventListener('click', handleNext);

  // Result screen buttons
  const retryBtn      = document.getElementById('retryBtn');
  const changeTopicBtn = document.getElementById('changeTopic');
  if (retryBtn)       retryBtn.addEventListener('click', startQuiz);
  if (changeTopicBtn) changeTopicBtn.addEventListener('click', goToStart);

  // ── Keyboard support ──────────────────────────────────
  document.addEventListener('keydown', (e) => {
    const quizActive = document.getElementById('quizScreen').classList.contains('active');
    if (!quizActive) return;

    const keyMap = { '1': 0, '2': 1, '3': 2, '4': 3, 'a': 0, 'b': 1, 'c': 2, 'd': 3 };
    const idx = keyMap[e.key.toLowerCase()];

    if (idx !== undefined) {
      const btn = document.querySelector(`.option-btn[data-index="${idx}"]`);
      if (btn && !btn.disabled) btn.click();
    }

    if ((e.key === 'Enter' || e.key === ' ') && !nextBtn.disabled) {
      nextBtn.click();
    }
  });

  // ── Quiz Flow ─────────────────────────────────────────

  function startQuiz() {
    Quiz.init();
    UI.hideHeaderScore();
    UI.showScreen('quizScreen');
    UI.setQuizMeta(Quiz.getTopicLabel(), Quiz.getDifficulty());
    showCurrentQuestion();
  }

  function showCurrentQuestion() {
    const state = Quiz.getState();
    const q     = Quiz.currentQuestion();

    UI.setProgress(Quiz.progress(), state.current, Quiz.getTotal());
    UI.renderQuestion(q, state.current);
    UI.disableNextBtn();
    UI.updateStreak(state.streak);
    UI.showHeaderScore(state.score);

    // Bind option clicks
    UI.bindOptionHandlers((chosenIdx) => {
      handleAnswer(chosenIdx);
    });

    // Start countdown timer
    Quiz.startTimer(
      (seconds) => UI.updateTimer(seconds),
      ()        => handleTimeUp()
    );
  }

  function handleAnswer(chosenIdx) {
    const result = Quiz.answer(chosenIdx);
    if (!result) return;

    UI.disableOptions();

    if (result.correct) {
      UI.markOptionCorrect(chosenIdx);
    } else {
      UI.markOptionWrong(chosenIdx);
      UI.revealCorrect(result.correctIndex);
    }

    UI.showFeedback(result.correct, result.explanation);
    UI.updateStreak(Quiz.getState().streak);
    UI.showHeaderScore(Quiz.getState().score);

    const isLast = Quiz.isLastQuestion();
    UI.enableNextBtn(isLast ? 'See results \u2192' : 'Next \u2192');
  }

  function handleTimeUp() {
    const result = Quiz.timeUp();
    if (!result) return;

    UI.disableOptions();
    UI.revealCorrect(result.correctIndex);
    UI.showTimeUpFeedback(result.explanation);
    UI.updateStreak(0);

    const isLast = Quiz.isLastQuestion();
    UI.enableNextBtn(isLast ? 'See results \u2192' : 'Next \u2192');
  }

  function handleNext() {
    Quiz.advance();

    if (Quiz.isFinished()) {
      showResult();
    } else {
      showCurrentQuestion();
    }
  }

  function showResult() {
    Quiz.clearTimer();
    UI.hideHeaderScore();
    const data = Quiz.results();
    UI.renderResult(data);
    UI.showScreen('resultScreen');
  }

  function goToStart() {
    Quiz.clearTimer();
    UI.hideHeaderScore();
    UI.showScreen('startScreen');
    // Rebuild topic grid with current topic highlighted
    UI.buildTopicGrid(Quiz.TOPICS, Quiz.getTopic(), (topic) => {
      Quiz.setTopic(topic);
    });
  }

});
