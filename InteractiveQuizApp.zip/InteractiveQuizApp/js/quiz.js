/**
 * quiz.js
 * Core quiz engine — state management, scoring, timer, validation.
 */

const Quiz = (() => {

  // ── State ──────────────────────────────────────────────
  let state = {
    topic:      'javascript',
    difficulty: 'easy',
    questions:  [],
    current:    0,
    total:      7,
    score:      0,
    streak:     0,
    maxStreak:  0,
    answered:   [],
    timer:      null,
    timeLeft:   25,
    answered:   [],
  };

  // ── Config ─────────────────────────────────────────────
  const TIMER_SECONDS = { easy: 25, medium: 20, hard: 15 };
  const TOPICS = { javascript: 'JavaScript', webdev: 'Web Dev', general: 'General Tech' };

  // ── Public API ─────────────────────────────────────────

  function setTopic(t)      { state.topic = t; }
  function setDifficulty(d) { state.difficulty = d; }
  function getTopic()       { return state.topic; }
  function getDifficulty()  { return state.difficulty; }
  function getTopicLabel()  { return TOPICS[state.topic] || state.topic; }
  function getState()       { return state; }
  function getTotal()       { return state.total; }

  function init() {
    const pool = [...QUESTIONS[state.topic][state.difficulty]];
    // Fisher-Yates shuffle
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    state.questions  = pool.slice(0, state.total);
    state.current    = 0;
    state.score      = 0;
    state.streak     = 0;
    state.maxStreak  = 0;
    state.answered   = [];
  }

  function currentQuestion() {
    return state.questions[state.current];
  }

  function isLastQuestion() {
    return state.current >= state.total - 1;
  }

  function progress() {
    return Math.round((state.current / state.total) * 100);
  }

  /**
   * Validate and record an answer.
   * Returns { correct, correctIndex, explanation }
   */
  function answer(chosenIndex) {
    const q = currentQuestion();
    if (!q) return null;

    clearTimer();

    const correct = chosenIndex === q.ans;

    if (correct) {
      state.score++;
      state.streak++;
      if (state.streak > state.maxStreak) state.maxStreak = state.streak;
    } else {
      state.streak = 0;
    }

    state.answered.push({
      q:       q.q,
      correct,
      chosen:  chosenIndex,
      ans:     q.ans,
      opts:    q.opts,
    });

    return { correct, correctIndex: q.ans, explanation: q.exp };
  }

  /**
   * Called when timer runs out. Records as unanswered.
   * Returns { correctIndex, explanation }
   */
  function timeUp() {
    const q = currentQuestion();
    if (!q) return null;

    clearTimer();
    state.streak = 0;

    state.answered.push({
      q:      q.q,
      correct: false,
      chosen: -1,
      ans:    q.ans,
      opts:   q.opts,
    });

    return { correctIndex: q.ans, explanation: q.exp };
  }

  function advance() {
    state.current++;
  }

  function isFinished() {
    return state.current >= state.total;
  }

  // ── Timer ──────────────────────────────────────────────

  function startTimer(onTick, onExpire) {
    clearTimer();
    state.timeLeft = TIMER_SECONDS[state.difficulty];
    onTick(state.timeLeft);

    state.timer = setInterval(() => {
      state.timeLeft--;
      onTick(state.timeLeft);
      if (state.timeLeft <= 0) {
        clearTimer();
        onExpire();
      }
    }, 1000);
  }

  function clearTimer() {
    if (state.timer) {
      clearInterval(state.timer);
      state.timer = null;
    }
  }

  // ── Results ────────────────────────────────────────────

  function results() {
    const pct = Math.round((state.score / state.total) * 100);
    let grade, gradeColor;

    if      (pct >= 90) { grade = 'Outstanding!';     gradeColor = 'var(--success)'; }
    else if (pct >= 75) { grade = 'Great job!';        gradeColor = 'var(--success)'; }
    else if (pct >= 60) { grade = 'Good effort!';      gradeColor = 'var(--warning)'; }
    else if (pct >= 40) { grade = 'Keep practising!';  gradeColor = 'var(--warning)'; }
    else                { grade = 'Keep going!';        gradeColor = 'var(--danger)';  }

    return {
      score:      state.score,
      total:      state.total,
      pct,
      grade,
      gradeColor,
      maxStreak:  state.maxStreak,
      wrong:      state.total - state.score,
      answered:   state.answered,
      topic:      getTopicLabel(),
      difficulty: state.difficulty,
    };
  }

  return {
    setTopic, setDifficulty, getTopic, getDifficulty,
    getTopicLabel, getState, getTotal,
    init, currentQuestion, isLastQuestion,
    progress, answer, timeUp, advance, isFinished,
    startTimer, clearTimer, results,
    TOPICS,
  };

})();
