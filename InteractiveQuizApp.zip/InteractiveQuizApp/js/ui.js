/**
 * ui.js
 * All DOM rendering and UI update functions.
 * Kept separate from quiz logic for clean separation of concerns.
 */

const UI = (() => {

  // ── Screen Management ──────────────────────────────────
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const screen = document.getElementById(id);
    if (screen) screen.classList.add('active');
  }

  // ── Start Screen ───────────────────────────────────────
  function buildTopicGrid(topics, activeTopic, onSelect) {
    const grid = document.getElementById('topicGrid');
    if (!grid) return;
    grid.innerHTML = Object.entries(topics).map(([key, label]) => `
      <button class="topic-btn${key === activeTopic ? ' active' : ''}" data-topic="${key}">
        ${label}
      </button>
    `).join('');

    grid.querySelectorAll('.topic-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        grid.querySelectorAll('.topic-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        onSelect(btn.dataset.topic);
      });
    });
  }

  // ── Quiz Screen ────────────────────────────────────────
  function setQuizMeta(topicLabel, difficulty) {
    const el = document.getElementById('quizTopicLabel');
    const badge = document.getElementById('diffBadge');
    if (el)    el.textContent = topicLabel;
    if (badge) badge.textContent = difficulty.charAt(0).toUpperCase() + difficulty.slice(1);
  }

  function setProgress(pct, current, total) {
    const bar   = document.getElementById('progressBar');
    const label = document.getElementById('progressLabel');
    if (bar)   bar.style.width = pct + '%';
    if (label) label.textContent = (current + 1) + ' / ' + total;
  }

  function renderQuestion(q, qIndex) {
    const numEl  = document.getElementById('qNumber');
    const textEl = document.getElementById('qText');
    if (numEl)  numEl.textContent  = 'Question ' + (qIndex + 1);
    if (textEl) textEl.textContent = q.q;

    // Clear feedback
    hideFeedback();

    // Render options
    const grid = document.getElementById('optionsGrid');
    if (!grid) return;

    const keys = ['A', 'B', 'C', 'D'];
    grid.innerHTML = q.opts.map((opt, i) => `
      <button class="option-btn" data-index="${i}">
        <span class="opt-key">${keys[i]}</span>
        <span class="opt-text">${opt}</span>
      </button>
    `).join('');
  }

  function bindOptionHandlers(onSelect) {
    const grid = document.getElementById('optionsGrid');
    if (!grid) return;
    grid.querySelectorAll('.option-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.disabled) return;
        onSelect(parseInt(btn.dataset.index, 10));
      });
    });
  }

  function disableOptions() {
    document.querySelectorAll('.option-btn').forEach(btn => btn.disabled = true);
  }

  function markOptionCorrect(index) {
    const btn = document.querySelector(`.option-btn[data-index="${index}"]`);
    if (btn) btn.classList.add('correct');
  }

  function markOptionWrong(index) {
    const btn = document.querySelector(`.option-btn[data-index="${index}"]`);
    if (btn) btn.classList.add('wrong');
  }

  function revealCorrect(index) {
    const btn = document.querySelector(`.option-btn[data-index="${index}"]`);
    if (btn) btn.classList.add('reveal-correct');
  }

  // ── Timer ──────────────────────────────────────────────
  function updateTimer(seconds) {
    const badge = document.getElementById('timerBadge');
    if (!badge) return;
    badge.textContent = '\u23F3 ' + seconds + 's';
    if (seconds <= 5) {
      badge.classList.add('urgent');
    } else {
      badge.classList.remove('urgent');
    }
  }

  // ── Feedback ───────────────────────────────────────────
  function showFeedback(correct, explanation) {
    const box = document.getElementById('feedbackBox');
    if (!box) return;
    const label = correct ? 'Correct!' : 'Incorrect.';
    box.innerHTML = `<span class="fb-label">${label}</span>${explanation}`;
    box.className = 'feedback-box show ' + (correct ? 'correct' : 'wrong');
  }

  function showTimeUpFeedback(explanation) {
    const box = document.getElementById('feedbackBox');
    if (!box) return;
    box.innerHTML = `<span class="fb-label">Time's up!</span>${explanation}`;
    box.className = 'feedback-box show wrong';
  }

  function hideFeedback() {
    const box = document.getElementById('feedbackBox');
    if (box) box.className = 'feedback-box';
  }

  // ── Next Button ────────────────────────────────────────
  function enableNextBtn(label) {
    const btn = document.getElementById('nextBtn');
    if (btn) {
      btn.disabled = false;
      btn.textContent = label || 'Next \u2192';
    }
  }

  function disableNextBtn() {
    const btn = document.getElementById('nextBtn');
    if (btn) btn.disabled = true;
  }

  // ── Streak ─────────────────────────────────────────────
  function updateStreak(streak) {
    const val  = document.getElementById('streakVal');
    const fire = document.getElementById('streakFire');
    if (val) val.textContent = streak;
    if (fire) {
      if (streak >= 3) {
        fire.textContent = '\uD83D\uDD25';
        fire.classList.add('show');
      } else {
        fire.classList.remove('show');
      }
    }
  }

  // ── Header Score ───────────────────────────────────────
  function showHeaderScore(score) {
    const wrap = document.getElementById('headerScore');
    const val  = document.getElementById('liveScore');
    if (wrap) wrap.style.display = 'block';
    if (val)  val.textContent = score;
  }

  function hideHeaderScore() {
    const wrap = document.getElementById('headerScore');
    if (wrap) wrap.style.display = 'none';
  }

  // ── Result Screen ──────────────────────────────────────
  function renderResult(data) {
    const scoreEl = document.getElementById('resultScore');
    const pctEl   = document.getElementById('resultPct');
    const gradeEl = document.getElementById('resultGrade');
    const statsEl = document.getElementById('resultStatsGrid');
    const listEl  = document.getElementById('reviewList');

    if (scoreEl) scoreEl.innerHTML = `${data.score}<span>/${data.total}</span>`;
    if (pctEl)   pctEl.textContent  = data.pct + '% correct';
    if (gradeEl) {
      gradeEl.textContent = data.grade;
      gradeEl.style.color = data.gradeColor;
    }

    if (statsEl) {
      statsEl.innerHTML = `
        <div class="stat-box">
          <div class="stat-val">${data.score}</div>
          <div class="stat-lbl">Correct</div>
        </div>
        <div class="stat-box">
          <div class="stat-val">${data.wrong}</div>
          <div class="stat-lbl">Incorrect</div>
        </div>
        <div class="stat-box">
          <div class="stat-val">${data.maxStreak}</div>
          <div class="stat-lbl">Best streak</div>
        </div>
      `;
    }

    if (listEl) {
      listEl.innerHTML = data.answered.map((a, i) => {
        const yourAnswer = a.chosen >= 0 ? a.opts[a.chosen] : 'Timed out';
        const correctAnswer = a.opts[a.ans];
        return `
          <div class="review-item ${a.correct ? 'ok' : 'fail'}">
            <div class="review-item-q">${i + 1}. ${a.q}</div>
            <div class="review-item-a">
              ${a.correct
                ? 'Your answer: ' + correctAnswer
                : 'Your answer: ' + yourAnswer + ' &nbsp;&bull;&nbsp; Correct: ' + correctAnswer
              }
            </div>
          </div>
        `;
      }).join('');
    }
  }

  return {
    showScreen,
    buildTopicGrid,
    setQuizMeta,
    setProgress,
    renderQuestion,
    bindOptionHandlers,
    disableOptions,
    markOptionCorrect,
    markOptionWrong,
    revealCorrect,
    updateTimer,
    showFeedback,
    showTimeUpFeedback,
    hideFeedback,
    enableNextBtn,
    disableNextBtn,
    updateStreak,
    showHeaderScore,
    hideHeaderScore,
    renderResult,
  };

})();
